<meta charset="utf-8">
<?php
@session_start();

//session_destroy();

unset($_SESSION['sid']);
unset($_SESSION['sname']);

echo "<script>";
echo "window.location='../index1.php';";
echo "</script>";
?>