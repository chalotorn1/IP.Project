<meta charset="utf-8">


<?php
	if(isset($_GET['id'])){
		include_once("connectdb_admin.php");
		
		$sql = "delete from od where odID ='".$_GET['id']."' ";
		mysqli_query($conn,$sql) or die('ลบข้อมูลไม่ได้');	
		
		
		echo "<script>";
		echo "alert('ลบข้อมูลสำเร็จ');";
	    echo "window.location='tableorder.php';";
		echo "</script>";
	}
?>
</body>
</html>