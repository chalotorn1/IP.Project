<?php
	 include_once('connectdb_admin.php');
		
	$sql2 = "SELECT * FROM food WHERE food_id = '".$_GET['id']."' ";
	$result2 = mysqli_query($conn, $sql2);
	$data2 = mysqli_fetch_array($result2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

	<link href="bootstrap.css" rel="stylesheet">
    
</head>

<body>
<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
<fieldset>

<!-- Form Name -->
<legend align="center">ฟอร์มแก้ไขข้อมูลสินค้า</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="a">ID</label>  
  <div class="col-md-4">
  <input id="a" name="a" type="text" placeholder="" class="form-control input-md" required="" value="<?=$data2['food_id'];?>" readonly>
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="b">ชื่ออาหาร</label>  
  <div class="col-md-4">
  <input id="b" name="b" type="text" placeholder="" class="form-control input-md" required="" value="<?=$data2['food_name'];?>">
    
  </div>
</div>


<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="c">ราคาอาหาร</label>  
  <div class="col-md-4">
  <input id="c" name="c" type="number" class="form-control input-md" required="" value="<?=$data2['price'];?>">
    
  </div>
</div>


<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="d">รายละเอียดสินค้า</label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="d" name="d"><?=$data2['detail'];?></textarea>
  </div>
</div>
   
<!-- File Button --> 
<div class="form-group">
  <label class="col-md-4 control-label" for="e">รูปอาหาร</label>
  <div class="col-md-4">
    <input id="e" name="e" class="input-file" type="file">
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="Submit"></label>
  <div class="col-md-4">
    <button id="Submit" name="Submit" class="btn btn-primary">บันทึก</button>
  </div>
</div>

</fieldset>
</form>

<?php
	if(isset($_POST['Submit'])){
		include_once("connectdb_admin.php");
		
		
		if ($_FILES['e']['name']=="") {
			$sql = $sql = "UPDATE food SET food_name = '".$_POST['b']."', price = '".$_POST['c']."', detail = '".$_POST['d']."'
			WHERE food.`food_id` = '".$_POST['a']."';";
			
				
		
			
		} else {
			$sql = "UPDATE food SET food_name = '".$_POST['b']."', price = '".$_POST['c']."', detail = '".$_POST['d']."' , image = '".$_FILES['e']['name']."' 
			WHERE food.`food_id` = '".$_POST['a']."';";
			
			@copy($_FILES['e']['tmp_name'], "image/".$_FILES['e']['name']);
			
		}
		mysqli_query($conn,$sql) or die('แก้ไขข้อมูลไม่ได้');
		
		echo "<script>";
		echo "alert('แก้ไขข้อมูลสำเร็จ');";
		echo "window.location='menu.php';";
		echo "</script>";
	}
?>

</body>
</html